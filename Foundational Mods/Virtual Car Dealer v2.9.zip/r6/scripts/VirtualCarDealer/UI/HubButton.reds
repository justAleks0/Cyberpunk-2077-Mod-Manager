import Codeware.UI.*

public class CustomHubButton extends CustomButton {
	protected let m_icon: wref<inkImage>;

	protected let m_fluff: wref<inkImage>;

  protected let m_leftSideBg: wref<inkImage>;

  protected let m_leftSideFg: wref<inkImage>;

	protected let m_hover: wref<inkFlex>;

	protected let m_disabledRootAnimDef: ref<inkAnimDef>;

	protected let m_disabledRootAnimProxy: ref<inkAnimProxy>;

	protected let m_hoverFillAnimDef: ref<inkAnimDef>;

	protected let m_hoverFillAnimProxy: ref<inkAnimProxy>;

	protected func CreateWidgets() -> Void {
		let root: ref<inkCanvas> = new inkCanvas();
		root.SetName(n"button");
		root.SetSize(Vector2(500.0, 105.0)); // Big Mode = 160.0
		root.SetAnchorPoint(Vector2(0.5, 0.5));
		root.SetInteractive(true);

		let flexContainer: ref<inkFlex> = new inkFlex();
		flexContainer.SetName(n"flexContainer");
		flexContainer.SetMargin(inkMargin(15.0, 0.0, 0.0, 0.0));
		flexContainer.Reparent(root);
		
		let background: ref<inkImage> = new inkImage();
		background.SetName(n"background");
		background.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		background.SetTexturePart(n"button_big2_bg");
		background.SetNineSliceScale(true);
		background.SetAnchorPoint(Vector2(0.5, 0.5));
		background.SetOpacity(1.0);
		background.SetTintColor(HDRColor(0.054902, 0.054902, 0.090196, 1.0));
		background.SetSize(Vector2(532.0, 345.0));
		background.Reparent(flexContainer);
		
		let frame: ref<inkImage> = new inkImage();
		frame.SetName(n"frame");
		frame.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		frame.SetTexturePart(n"button_big2_fg");
		frame.SetNineSliceScale(true);
		frame.SetAnchorPoint(Vector2(0.5, 0.5));
		frame.SetTintColor(HDRColor(0.411765, 0.086275, 0.090196, 1.0));
		frame.SetSize(Vector2(532.0, 345.0));
		frame.Reparent(flexContainer);
		
		let backgroundLeftBg: ref<inkImage> = new inkImage();
		backgroundLeftBg.SetName(n"background_leftBg");
		backgroundLeftBg.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		backgroundLeftBg.SetTexturePart(n"item_side_bg");
		backgroundLeftBg.SetNineSliceScale(true);
		backgroundLeftBg.SetMargin(inkMargin(-15.0, 0.0, 0.0, 0.0));
		backgroundLeftBg.SetHAlign(inkEHorizontalAlign.Left);
		backgroundLeftBg.SetAnchorPoint(Vector2(0.5, 0.5));
		backgroundLeftBg.SetOpacity(1.0);
		backgroundLeftBg.SetTintColor(HDRColor(0.411765, 0.086275, 0.090196, 1.0));
		backgroundLeftBg.SetSize(Vector2(16.0, 345.0));
		backgroundLeftBg.Reparent(flexContainer);
		
		let backgroundLeftFrame: ref<inkImage> = new inkImage();
		backgroundLeftFrame.SetName(n"background_leftFrame");
		backgroundLeftFrame.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		backgroundLeftFrame.SetTexturePart(n"item_side_fg");
		backgroundLeftFrame.SetNineSliceScale(true);
		backgroundLeftFrame.SetMargin(inkMargin(-15.0, 0.0, 0.0, 0.0));
		backgroundLeftFrame.SetHAlign(inkEHorizontalAlign.Left);
		backgroundLeftFrame.SetAnchorPoint(Vector2(0.5, 0.5));
		backgroundLeftFrame.SetTintColor(HDRColor(0.411765, 0.086275, 0.090196, 1.0));
		backgroundLeftFrame.SetSize(Vector2(16.0, 345.0));
		backgroundLeftFrame.Reparent(flexContainer);
		
		let container: ref<inkHorizontalPanel> = new inkHorizontalPanel();
		container.SetName(n"container");
		container.SetFitToContent(true);
		container.SetMargin(inkMargin(0.0, 5.0, 0.0, 0.0));
		container.SetHAlign(inkEHorizontalAlign.Left);
		container.SetVAlign(inkEVerticalAlign.Top);
		container.Reparent(flexContainer);
		
		let inkVerticalPanelWidget8: ref<inkVerticalPanel> = new inkVerticalPanel();
		inkVerticalPanelWidget8.SetName(n"inkVerticalPanelWidget8");
		inkVerticalPanelWidget8.SetFitToContent(true);
		inkVerticalPanelWidget8.SetMargin(inkMargin(20.0, 0.0, -10.0, 0.0));
		inkVerticalPanelWidget8.Reparent(container);
		
		let icon: ref<inkImage> = new inkImage();
		icon.SetName(n"icon");
		icon.SetAtlasResource(r"base\\gameplay\\gui\\fullscreen\\hub_menu\\hub_atlas.inkatlas");
		icon.SetHAlign(inkEHorizontalAlign.Center);
		icon.SetVAlign(inkEVerticalAlign.Center);
		icon.SetAnchorPoint(Vector2(0.5, 0.5));
		icon.SetSizeRule(inkESizeRule.Stretch);
		// icon.SetTintColor(HDRColor(0.368627, 0.964706, 1.0, 1.0));
		icon.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
		icon.BindProperty(n"tintColor", n"MainColors.Blue");
		icon.SetSize(Vector2(80.0, 80.0));
		icon.SetScale(Vector2(0.8, 0.8));
		icon.Reparent(inkVerticalPanelWidget8);
		
		let fluff: ref<inkImage> = new inkImage();
		fluff.SetName(n"fluff");
		fluff.SetAtlasResource(r"base\\gameplay\\gui\\common\\icons\\atlas_common.inkatlas");
		fluff.SetTexturePart(n"fluffcc35_3");
		fluff.SetFitToContent(true);
		fluff.SetMargin(inkMargin(0.0, 0.0, 0.0, 16.0));
		fluff.SetHAlign(inkEHorizontalAlign.Center);
		fluff.SetVAlign(inkEVerticalAlign.Center);
		fluff.SetAnchorPoint(Vector2(0.5, 0.5));
		fluff.SetOpacity(0.8);
		// fluff.SetTintColor(HDRColor(0.368627, 0.964706, 1.0, 1.0));
		fluff.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
		fluff.BindProperty(n"tintColor", n"MainColors.Blue");
		fluff.SetSize(Vector2(90.0, 80.0));
		fluff.Reparent(inkVerticalPanelWidget8);
		
		let label: ref<inkText> = new inkText();
		label.SetName(n"label");
		label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
		label.SetFontStyle(n"Semi-Bold");
		label.SetFontSize(48);
		label.SetLetterCase(textLetterCase.UpperCase);
		label.SetVerticalAlignment(textVerticalAlignment.Center);
		label.SetContentHAlign(inkEHorizontalAlign.Center);
		label.SetContentVAlign(inkEVerticalAlign.Center);
		label.SetText("STATS");
		label.SetMargin(inkMargin(20.0, -5.0, 0.0, 0.0));
		label.SetHAlign(inkEHorizontalAlign.Left);
		label.SetVAlign(inkEVerticalAlign.Center);
		// label.SetTintColor(HDRColor(0.368627, 0.964706, 1.0, 1.0));
		label.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
		label.BindProperty(n"tintColor", n"MainColors.Blue");
		label.SetSize(Vector2(360.0, 120.0));
		label.Reparent(container);

		let hoverFrames: ref<inkFlex> = new inkFlex();
		hoverFrames.SetName(n"hoverFrames");
		hoverFrames.SetOpacity(0.0);
		hoverFrames.SetSize(Vector2(100.0, 100.0));
		hoverFrames.Reparent(flexContainer);
		
		let frameHovered: ref<inkImage> = new inkImage();
		frameHovered.SetName(n"frameHovered");
		frameHovered.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		frameHovered.SetTexturePart(n"button_big2_fg");
		frameHovered.SetNineSliceScale(true);
		frameHovered.SetAnchorPoint(Vector2(0.5, 0.5));
		frameHovered.SetTintColor(HDRColor(1.1761, 0.3809, 0.3476, 1.0));
		frameHovered.SetSize(Vector2(532.0, 345.0));
		frameHovered.Reparent(hoverFrames);
		
		let frameHoveredBg: ref<inkImage> = new inkImage();
		frameHoveredBg.SetName(n"frameHoveredBg");
		frameHoveredBg.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		frameHoveredBg.SetTexturePart(n"button_big2_bg");
		frameHoveredBg.SetNineSliceScale(true);
		frameHoveredBg.SetAnchorPoint(Vector2(0.5, 0.5));
		frameHoveredBg.SetOpacity(0.05);
		frameHoveredBg.SetTintColor(HDRColor(1.1761, 0.3809, 0.3476, 1.0));
		frameHoveredBg.SetSize(Vector2(532.0, 345.0));
		frameHoveredBg.Reparent(hoverFrames);
		
		let backgroundLeftHover: ref<inkImage> = new inkImage();
		backgroundLeftHover.SetName(n"background_leftHover");
		backgroundLeftHover.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		backgroundLeftHover.SetTexturePart(n"item_side_fg");
		backgroundLeftHover.SetNineSliceScale(true);
		backgroundLeftHover.SetMargin(inkMargin(-15.0, 0.0, 0.0, 0.0));
		backgroundLeftHover.SetHAlign(inkEHorizontalAlign.Left);
		backgroundLeftHover.SetAnchorPoint(Vector2(0.5, 0.5));
		backgroundLeftHover.SetTintColor(HDRColor(1.1761, 0.3809, 0.3476, 1.0));
		backgroundLeftHover.SetSize(Vector2(16.0, 345.0));
		backgroundLeftHover.Reparent(hoverFrames);
		
		let backgroundLeftBg: ref<inkImage> = new inkImage();
		backgroundLeftBg.SetName(n"background_leftBg");
		backgroundLeftBg.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
		backgroundLeftBg.SetTexturePart(n"item_side_bg");
		backgroundLeftBg.SetNineSliceScale(true);
		backgroundLeftBg.SetMargin(inkMargin(-15.0, 0.0, 0.0, 0.0));
		backgroundLeftBg.SetHAlign(inkEHorizontalAlign.Left);
		backgroundLeftBg.SetAnchorPoint(Vector2(0.5, 0.5));
		backgroundLeftBg.SetOpacity(1.0); // Big Mode = 0.05
		backgroundLeftBg.SetTintColor(HDRColor(1.1761, 0.3809, 0.3476, 1.0));
		backgroundLeftBg.SetSize(Vector2(16.0, 345.0));
		backgroundLeftBg.Reparent(hoverFrames);

		let minSize: ref<inkRectangle> = new inkRectangle();
		minSize.SetName(n"minSize");
		minSize.SetVisible(false);
		minSize.SetAffectsLayoutWhenHidden(true);
		minSize.SetHAlign(inkEHorizontalAlign.Left);
		minSize.SetVAlign(inkEVerticalAlign.Center);
		minSize.SetSize(Vector2(485.0, 100.0));
		minSize.Reparent(flexContainer);

		this.m_root = root;
		this.m_label = label;
		this.m_icon = icon;
		this.m_fluff = fluff;
		this.m_hover = hoverFrames;
    this.m_leftSideBg = backgroundLeftBg;
    this.m_leftSideFg = backgroundLeftFrame;

		this.SetRootWidget(root);
	}

	protected func CreateAnimations() -> Void {
		let disabledRootAlphaAnim: ref<inkAnimTransparency> = new inkAnimTransparency();
		disabledRootAlphaAnim.SetStartTransparency(1.0);
		disabledRootAlphaAnim.SetEndTransparency(0.3);
		disabledRootAlphaAnim.SetDuration(this.m_useAnimations ? 0.05 : 0.0001);

		this.m_disabledRootAnimDef = new inkAnimDef();
		this.m_disabledRootAnimDef.AddInterpolator(disabledRootAlphaAnim);

		let hoverFillAlphaAnim: ref<inkAnimTransparency> = new inkAnimTransparency();
		hoverFillAlphaAnim.SetStartTransparency(0.0);
		hoverFillAlphaAnim.SetEndTransparency(1.0);
		hoverFillAlphaAnim.SetDuration(this.m_useAnimations ? 0.2 : 0.0001);

		this.m_hoverFillAnimDef = new inkAnimDef();
		this.m_hoverFillAnimDef.AddInterpolator(hoverFillAlphaAnim);
	}

	protected func ApplyDisabledState() -> Void {
		let reverseAnimOpts: inkAnimOptions;
		reverseAnimOpts.playReversed = !this.m_isDisabled;

		this.m_disabledRootAnimProxy.Stop();
		this.m_disabledRootAnimProxy = this.m_root.PlayAnimationWithOptions(this.m_disabledRootAnimDef, reverseAnimOpts);
	}

	protected func ApplyHoveredState() -> Void {
		let reverseAnimOpts: inkAnimOptions;
		reverseAnimOpts.playReversed = !this.m_isHovered || this.m_isDisabled;

		this.m_hoverFillAnimProxy.Stop();
		this.m_hoverFillAnimProxy = this.m_hover.PlayAnimationWithOptions(this.m_hoverFillAnimDef, reverseAnimOpts);
	}

	protected func ApplyPressedState() -> Void {
		
	}

	public func SetIcon(icon: CName) -> Void {
		this.m_icon.SetTexturePart(icon);

		if NotEquals(icon, n"") {
			this.m_icon.SetVisible(true);
		} else {
			this.m_icon.SetVisible(false);
			this.m_fluff.SetVisible(false);
		}
	}

	public func SetIcon(icon: CName, atlas: ResRef) -> Void {
		this.m_icon.SetAtlasResource(atlas);
		this.SetIcon(icon);
	}

  public func SetTextColor(colorName: CName) -> Void {
    this.m_label.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_label.BindProperty(n"tintColor", colorName);
  }

  public func SetHoverColor(colorName: CName) -> Void {
    let root: ref<inkCompoundWidget> = this.m_hover;
    let numChildren: Int32 = root.GetNumChildren();
    let child: ref<inkImage>;
    let i: Int32 = 0;
    while i < numChildren {
      child = root.GetWidget(i) as inkImage;
      child.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
      child.BindProperty(n"tintColor", colorName);
      i += 1;
    };
  }

  public func SetFluffColor(colorName: CName) -> Void {
    this.m_fluff.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_fluff.BindProperty(n"tintColor", colorName);
  }

  public func SetLeftSideColor(colorName: CName) -> Void {
    this.m_leftSideBg.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_leftSideBg.BindProperty(n"tintColor", colorName);
    this.m_leftSideFg.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_leftSideFg.BindProperty(n"tintColor", colorName);
  }

  public func SetHoveredState(isHovered: Bool) {
    super.SetHoveredState(isHovered);
  }

  public func SetDisabledState(isDisabled: Bool) {
    super.SetDisabledState(isDisabled);
  }

	public static func Create() -> ref<CustomHubButton> {
		let self: ref<CustomHubButton> = new CustomHubButton();
		self.CreateInstance();

		return self;
	}
}
